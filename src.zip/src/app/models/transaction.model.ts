export interface Transaction {
    toId: string
    to: string
    at: number
    amount: number
}
